using System.Security.Cryptography;

namespace AESWeb.Services
{
    public static class KeyGenerator
    {
        public static string GenerateKey(int bits)
        {
            int bytes = bits / 8;

            byte[] key = new byte[bytes];

            RandomNumberGenerator.Fill(key);

            return Convert.ToHexString(key);
        }

        public static string GenerateIV()
        {
            byte[] iv = new byte[16];

            RandomNumberGenerator.Fill(iv);

            return Convert.ToHexString(iv);
        }
    }
}