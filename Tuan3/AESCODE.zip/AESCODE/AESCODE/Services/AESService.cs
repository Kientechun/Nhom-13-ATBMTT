using System.Text;
using System.Security.Cryptography;

namespace AESWeb.Services
{
    public static class AESService
    {
        // ==================== CORE AES ALGORITHM ====================
        private static readonly byte[] Sbox = new byte[256]
        {
            0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
            0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
            0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
            0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
            0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
            0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
            0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
            0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
            0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
            0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
            0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
            0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
            0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
            0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
            0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
            0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
        };

        private static readonly byte[] InvSbox = new byte[256];
        private static readonly byte[] Rcon = new byte[] {
            0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36
        };

        static AESService()
        {
            for (int i = 0; i < 256; i++)
                InvSbox[Sbox[i]] = (byte)i;
        }

        private static byte[][] KeyExpansion(byte[] key, int keySizeBits)
        {
            int Nk = keySizeBits / 32;
            int Nr = Nk + 6;
            int Nb = 4;
            int totalWords = Nb * (Nr + 1);
            byte[][] w = new byte[totalWords][];
            for (int i = 0; i < totalWords; i++)
                w[i] = new byte[4];

            for (int i = 0; i < Nk; i++)
            {
                w[i][0] = key[4 * i];
                w[i][1] = key[4 * i + 1];
                w[i][2] = key[4 * i + 2];
                w[i][3] = key[4 * i + 3];
            }

            for (int i = Nk; i < totalWords; i++)
            {
                byte[] temp = (byte[])w[i - 1].Clone();
                if (i % Nk == 0)
                {
                    temp = SubWord(RotWord(temp));
                    temp[0] ^= Rcon[i / Nk];
                }
                else if (Nk > 6 && i % Nk == 4)
                {
                    temp = SubWord(temp);
                }

                for (int j = 0; j < 4; j++)
                    w[i][j] = (byte)(w[i - Nk][j] ^ temp[j]);
            }
            return w;
        }

        private static byte[] SubWord(byte[] word)
        {
            byte[] result = new byte[4];
            for (int i = 0; i < 4; i++)
                result[i] = Sbox[word[i]];
            return result;
        }

        private static byte[] RotWord(byte[] word)
        {
            return new byte[] { word[1], word[2], word[3], word[0] };
        }

        private static void AddRoundKey(byte[,] state, byte[][] roundKey, int round)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    state[j, i] ^= roundKey[round * 4 + i][j];
                }
            }
        }

        private static void SubBytes(byte[,] state)
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    state[i, j] = Sbox[state[i, j]];
        }

        private static void InvSubBytes(byte[,] state)
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    state[i, j] = InvSbox[state[i, j]];
        }

        private static void ShiftRows(byte[,] state)
        {
            for (int i = 1; i < 4; i++)
            {
                byte[] temp = new byte[4];
                for (int j = 0; j < 4; j++)
                    temp[j] = state[i, (j + i) % 4];
                for (int j = 0; j < 4; j++)
                    state[i, j] = temp[j];
            }
        }

        private static void InvShiftRows(byte[,] state)
        {
            for (int i = 1; i < 4; i++)
            {
                byte[] temp = new byte[4];
                for (int j = 0; j < 4; j++)
                    temp[j] = state[i, (j - i + 4) % 4];
                for (int j = 0; j < 4; j++)
                    state[i, j] = temp[j];
            }
        }

        private static byte GMul(byte a, byte b)
        {
            byte p = 0;
            for (int i = 0; i < 8; i++)
            {
                if ((b & 1) != 0) p ^= a;
                bool hiBitSet = (a & 0x80) != 0;
                a <<= 1;
                if (hiBitSet) a ^= 0x1B;
                b >>= 1;
            }
            return p;
        }

        private static void MixColumns(byte[,] state)
        {
            for (int c = 0; c < 4; c++)
            {
                byte a0 = state[0, c];
                byte a1 = state[1, c];
                byte a2 = state[2, c];
                byte a3 = state[3, c];

                state[0, c] = (byte)(GMul(0x02, a0) ^ GMul(0x03, a1) ^ a2 ^ a3);
                state[1, c] = (byte)(a0 ^ GMul(0x02, a1) ^ GMul(0x03, a2) ^ a3);
                state[2, c] = (byte)(a0 ^ a1 ^ GMul(0x02, a2) ^ GMul(0x03, a3));
                state[3, c] = (byte)(GMul(0x03, a0) ^ a1 ^ a2 ^ GMul(0x02, a3));
            }
        }

        private static void InvMixColumns(byte[,] state)
        {
            for (int c = 0; c < 4; c++)
            {
                byte a0 = state[0, c];
                byte a1 = state[1, c];
                byte a2 = state[2, c];
                byte a3 = state[3, c];

                state[0, c] = (byte)(GMul(0x0E, a0) ^ GMul(0x0B, a1) ^ GMul(0x0D, a2) ^ GMul(0x09, a3));
                state[1, c] = (byte)(GMul(0x09, a0) ^ GMul(0x0E, a1) ^ GMul(0x0B, a2) ^ GMul(0x0D, a3));
                state[2, c] = (byte)(GMul(0x0D, a0) ^ GMul(0x09, a1) ^ GMul(0x0E, a2) ^ GMul(0x0B, a3));
                state[3, c] = (byte)(GMul(0x0B, a0) ^ GMul(0x0D, a1) ^ GMul(0x09, a2) ^ GMul(0x0E, a3));
            }
        }

        private static byte[] EncryptBlock(byte[] input, byte[] key, int keySizeBits)
        {
            int Nk = keySizeBits / 32;
            int Nr = Nk + 6;
            byte[,] state = new byte[4, 4];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    state[i, j] = input[i + 4 * j];

            byte[][] w = KeyExpansion(key, keySizeBits);
            AddRoundKey(state, w, 0);

            for (int round = 1; round <= Nr - 1; round++)
            {
                SubBytes(state);
                ShiftRows(state);
                MixColumns(state);
                AddRoundKey(state, w, round);
            }

            SubBytes(state);
            ShiftRows(state);
            AddRoundKey(state, w, Nr);

            byte[] output = new byte[16];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    output[i + 4 * j] = state[i, j];
            return output;
        }

        private static byte[] DecryptBlock(byte[] input, byte[] key, int keySizeBits)
        {
            int Nk = keySizeBits / 32;
            int Nr = Nk + 6;
            byte[,] state = new byte[4, 4];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    state[i, j] = input[i + 4 * j];

            byte[][] w = KeyExpansion(key, keySizeBits);
            AddRoundKey(state, w, Nr);

            for (int round = Nr - 1; round >= 1; round--)
            {
                InvShiftRows(state);
                InvSubBytes(state);
                AddRoundKey(state, w, round);
                InvMixColumns(state);
            }

            InvShiftRows(state);
            InvSubBytes(state);
            AddRoundKey(state, w, 0);

            byte[] output = new byte[16];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    output[i + 4 * j] = state[i, j];
            return output;
        }

        // ==================== PKCS7 PADDING ====================
        private static byte[] AddPKCS7Padding(byte[] data, int blockSize = 16)
        {
            int paddingLen = blockSize - (data.Length % blockSize);
            byte[] padded = new byte[data.Length + paddingLen];
            Buffer.BlockCopy(data, 0, padded, 0, data.Length);
            for (int i = data.Length; i < padded.Length; i++)
                padded[i] = (byte)paddingLen;
            return padded;
        }

        private static byte[] RemovePKCS7Padding(byte[] data)
        {
            int padLen = data[data.Length - 1];
            if (padLen < 1 || padLen > 16)
                throw new Exception("Invalid padding");
            byte[] result = new byte[data.Length - padLen];
            Buffer.BlockCopy(data, 0, result, 0, result.Length);
            return result;
        }

        // ==================== CBC MODE ====================
        private static byte[] XORBlocks(byte[] a, byte[] b)
        {
            byte[] result = new byte[16];
            for (int i = 0; i < 16; i++)
                result[i] = (byte)(a[i] ^ b[i]);
            return result;
        }

        private static byte[] EncryptCBC(byte[] plain, byte[] key, byte[] iv, int keySizeBits)
        {
            byte[] padded = AddPKCS7Padding(plain);
            byte[] cipher = new byte[padded.Length];
            byte[] prev = (byte[])iv.Clone();

            for (int i = 0; i < padded.Length; i += 16)
            {
                byte[] block = new byte[16];
                Buffer.BlockCopy(padded, i, block, 0, 16);
                byte[] xorBlock = XORBlocks(block, prev);
                byte[] encryptedBlock = EncryptBlock(xorBlock, key, keySizeBits);
                Buffer.BlockCopy(encryptedBlock, 0, cipher, i, 16);
                prev = encryptedBlock;
            }
            return cipher;
        }

        private static byte[] DecryptCBC(byte[] cipher, byte[] key, byte[] iv, int keySizeBits)
        {
            if (cipher.Length % 16 != 0)
                throw new Exception("Invalid cipher length");

            byte[] plain = new byte[cipher.Length];
            byte[] prev = (byte[])iv.Clone();

            for (int i = 0; i < cipher.Length; i += 16)
            {
                byte[] block = new byte[16];
                Buffer.BlockCopy(cipher, i, block, 0, 16);
                byte[] decryptedBlock = DecryptBlock(block, key, keySizeBits);
                byte[] xorBlock = XORBlocks(decryptedBlock, prev);
                Buffer.BlockCopy(xorBlock, 0, plain, i, 16);
                prev = block;
            }
            return RemovePKCS7Padding(plain);
        }

        // ==================== HELPER (như cũ) ====================
        private static byte[] ParseKeyOrIV(string text, int requiredBytes)
        {
            byte[] raw;
            if (text.Length % 2 == 0 && System.Text.RegularExpressions.Regex.IsMatch(text, @"^[0-9a-fA-F]+$"))
                raw = Convert.FromHexString(text);
            else
                raw = Encoding.UTF8.GetBytes(text);

            byte[] result = new byte[requiredBytes];
            Buffer.BlockCopy(raw, 0, result, 0, Math.Min(raw.Length, requiredBytes));
            return result;
        }

        // ==================== PUBLIC API ====================
        public static string Encrypt(string plainText, string keyText, string ivText, int keySize = 128)
        {
            int keyBytes = keySize / 8;
            byte[] key = ParseKeyOrIV(keyText, keyBytes);
            byte[] iv = ParseKeyOrIV(ivText, 16);
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] cipherBytes = EncryptCBC(plainBytes, key, iv, keySize);
            return Convert.ToHexString(cipherBytes);
        }

        public static string Decrypt(string cipherHex, string keyText, string ivText, int keySize = 128)
        {
            int keyBytes = keySize / 8;
            byte[] key = ParseKeyOrIV(keyText, keyBytes);
            byte[] iv = ParseKeyOrIV(ivText, 16);
            byte[] cipherBytes = Convert.FromHexString(cipherHex);
            byte[] plainBytes = DecryptCBC(cipherBytes, key, iv, keySize);
            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
