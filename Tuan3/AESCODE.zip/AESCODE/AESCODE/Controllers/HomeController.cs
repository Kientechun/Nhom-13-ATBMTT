using Microsoft.AspNetCore.Mvc;
using AESWeb.Models;
using AESWeb.Services;

namespace AESWeb.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            AESViewModel model = new AESViewModel();
            // Không hardcode key nữa; để sinh key ngẫu nhiên khi load trang
            model.Key = KeyGenerator.GenerateKey(128);
            model.IV  = KeyGenerator.GenerateIV();
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(AESViewModel model)
        {
            try
            {
                if (model.ActionType == "decrypt")
                {
                    // Khi giải mã: người dùng nhập ciphertext vào ô CipherInput
                    model.PlainText = AESService.Decrypt(
                        model.CipherInput,
                        model.Key,
                        model.IV,
                        model.KeySize);
                }
                else
                {
                    // Khi mã hóa: người dùng nhập plaintext vào ô PlainText
                    model.CipherText = AESService.Encrypt(
                        model.PlainText,
                        model.Key,
                        model.IV,
                        model.KeySize);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Lỗi: " + ex.Message);
            }

            return View(model);
        }

        [HttpGet]
        public JsonResult GenerateKey(int size)
        {
            string key = KeyGenerator.GenerateKey(size);
            return Json(key);
        }

        [HttpGet]
        public JsonResult GenerateIV()
        {
            string iv = KeyGenerator.GenerateIV();
            return Json(iv);
        }
    }
}
