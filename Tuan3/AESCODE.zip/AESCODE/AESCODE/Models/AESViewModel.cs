namespace AESWeb.Models
{
    public class AESViewModel
    {
        // Văn bản gốc (dùng khi mã hóa, và hiển thị kết quả giải mã)
        public string PlainText { get; set; } = "";

        // Kết quả mã hóa (hex)
        public string CipherText { get; set; } = "";

        // Văn bản cần giải mã (người dùng nhập hex vào đây)
        public string CipherInput { get; set; } = "";

        public string Key { get; set; } = "";

        public string IV { get; set; } = "";

        public string Mode { get; set; } = "CBC";

        public int KeySize { get; set; } = 128;

        public string ActionType { get; set; } = "";
    }
}
